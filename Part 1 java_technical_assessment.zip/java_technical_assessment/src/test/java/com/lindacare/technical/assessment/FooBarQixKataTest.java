package com.lindacare.technical.assessment;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(value = MethodSorters.NAME_ASCENDING)
public class FooBarQixKataTest {
	
	private FooBarQixKata kata = null;
	
	@Before
	public void arrange() {
		kata = new FooBarQixKata();
	}

	@Test(expected = IllegalArgumentException.class)
	public void test01_compute_WhenNumberMinus1_ThrowsIllegalArgumentException() {
		// Arrange
		int number = -1;
		
		// Act
		kata.compute(number);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void test02_compute_WhenNumberZero_ThrowsIllegalArgumentException() {
		// Arrange
		int number = 0;
		// Act
		kata.compute(number);
	}
	
	
	@Test
	public void test03_compute_WhenNumberdivby3and5_translateThreeFiveSevenZero() {
		// Arrange
		int number = 15;
		// Act
		kata.compute(number);
	}
		
	@Test
	public void test04_compute_WhenNumberdivby3and7_translateThreeFiveSevenZero() {
		// Arrange
		int number = 21;
		// Act
		kata.compute(number);
		
	}
	
	@Test
	public void test05_compute_WhenNumberdivby5and7_translateThreeFiveSevenZero() {
		// Arrange
		int number = 35;
		// Act
		kata.compute(number);
	}	
	
	@Test
	public void test06_compute_WhenNumberdivby3_5_7_translateThreeFiveSevenZero() {
		// Arrange
		int number = 105;
		// Act
		kata.compute(number);
	}
		
	@Test
	public void test07_compute_WhenNumberissquareof3_translateThreeFiveSevenZero() {
		// Arrange
		int number = 9;
		// Act
		kata.compute(number);
					
	}
	
	@Test
	public void test08_compute_WhenNumberissquareof5_translateThreeFiveSevenZero() {
		// Arrange
		int number = 25;
		// Act
		kata.compute(number);		

	}
	
	@Test
	public void test09_compute_WhenNumberissqaureof7_translateThreeFiveSevenZero() {
		// Arrange
		int number = 49;
		// Act
		kata.compute(number);
		
	}
	@Test
	public void test10_compute_WhenNumberdivby3_translateThreeFiveSevenZero() {
		// Arrange
		int number = 33;
		// Act
		kata.compute(number);
	}
	@Test
	public void test11_compute_WhenNumberdivby5_translateThreeFiveSevenZero() {
		// Arrange
		int number = 55;
		// Act
		kata.compute(number);
	}
	@Test
	public void test12_compute_WhenNumberdivby5_translateThreeFiveSevenZero() {
		// Arrange
		int number = 77;
		// Act
		kata.compute(number);
}
}
