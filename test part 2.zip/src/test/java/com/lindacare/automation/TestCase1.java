package com.lindacare.automation;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.SystemUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestCase1<age> {

	private WebDriver driver;
	private String basePath = System.getProperty("user.dir");

	@Test
	public void sampleTest() {
		WebElement headerDiv = driver.findElement(By.id("header"));

		String headerClass = headerDiv.getAttribute("class");

		Assert.assertEquals(headerClass, "container", "Header has class container");
		
		
	}
	@Test
	public void RateCalculator(){
		driver.get("C:\\Users\\nileshbh\\Desktop\\New folder\\Exercixe 3\\java_technical_assessment_automation\\InterestCalculator.html");
		String age = driver.findElement(By.className("form-group col-sm-2")).getText();
		WebElement amount = driver.findElement(By.className("form-group col-sm-10"));
		
		driver.findElement(By.id("btn-calculate")).click();
		}
		
	
	

	@BeforeClass
	public void beforeClass() {
		String phantomJSPath = basePath + "/lib/phantomjs";

		if (SystemUtils.IS_OS_WINDOWS) {
			phantomJSPath += ".exe";
		}

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);
		caps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY, phantomJSPath);
		driver = new PhantomJSDriver(caps);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String pageURL = "file:///" + basePath + "/InterestCalculator.html";

		driver.get(pageURL);
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
	}

}
